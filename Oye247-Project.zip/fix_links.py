import re

html_file = 'index.html'
with open(html_file, 'r', encoding='utf-8') as f:
    html = f.read()

# Fix navbar links
html = html.replace('href="#benefits"', 'href="#use-cases"')

# Fix footer links
html = html.replace('href="#features"', 'href="#use-cases"')
html = html.replace('href="#pricing"', 'href="#contact"')

with open(html_file, 'w', encoding='utf-8') as f:
    f.write(html)
print("Links fixed.")
