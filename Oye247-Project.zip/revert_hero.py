import re

# 1. Revert index.html
html_file = 'index.html'
with open(html_file, 'r', encoding='utf-8') as f:
    html = f.read()

# Revert fonts
new_fonts = 'family=Inter:wght@300;400;500;600&family=Outfit:wght@400;600;700;800&family=Playfair+Display:ital,wght@0,400;0,500;0,600;1,400;1,500;1,600&display=swap'
old_fonts = 'family=Inter:wght@300;400;500;600&family=Outfit:wght@400;600;700;800&display=swap'
html = html.replace(new_fonts, old_fonts)

# Revert Hero Section
new_hero_regex = r'<section class="hero redesigned-hero">.*?</section>'
original_hero_html = """<section class="hero">
        <canvas id="hero-canvas"></canvas>
        <div class="container hero-container">
            <div class="hero-content">
                <div class="badge">Next-Gen AI Automation</div>
                <h1 class="headline">Automate Your Business.<br><span class="text-gradient">Convert More Customers with AI.</span></h1>
                <p class="subheadline">Capture every lead, respond instantly, and close more deals with AI-powered automation.</p>
                <div class="hero-cta">
                    <a href="#demo" class="btn btn-primary">Get Demo <i class="ph ph-arrow-right"></i></a>
                    <a href="#contact" class="btn btn-secondary">Start Automation</a>
                </div>
            </div>
        </div>
    </section>"""
html = re.sub(new_hero_regex, original_hero_html, html, flags=re.DOTALL)

with open(html_file, 'w', encoding='utf-8') as f:
    f.write(html)
print("Reverted index.html")

# 2. Revert style.css
css_file = 'style.css'
with open(css_file, 'r', encoding='utf-8') as f:
    css = f.read()

if '/* --- Redesigned Hero Section --- */' in css:
    css = css.split('/* --- Redesigned Hero Section --- */')[0].strip()
    with open(css_file, 'w', encoding='utf-8') as f:
        f.write(css)
    print("Reverted style.css")

