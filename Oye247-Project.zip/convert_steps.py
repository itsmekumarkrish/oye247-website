import re

# Update index.html
html_file = 'index.html'
with open(html_file, 'r', encoding='utf-8') as f:
    html = f.read()

# Replace steps-grid with grid-3
html = html.replace('<div class="steps-grid">', '<div class="grid-3">')
# Replace step-card with card glass
html = html.replace('<div class="step-card">', '<div class="card glass">')

with open(html_file, 'w', encoding='utf-8') as f:
    f.write(html)
print("Updated index.html")

# Update style.css
css_file = 'style.css'
with open(css_file, 'r', encoding='utf-8') as f:
    css = f.read()

# Modify .step-number margin to align left
css = css.replace('margin: 0 auto 1.5rem auto;', 'margin: 0 0 1.5rem 0;')

with open(css_file, 'w', encoding='utf-8') as f:
    f.write(css)
print("Updated style.css")
