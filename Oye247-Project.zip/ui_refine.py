import re

css_file = 'style.css'
with open(css_file, 'r', encoding='utf-8') as f:
    css = f.read()

# 1. Typography tweaks
css = css.replace('line-height: 1.6;', 'line-height: 1.7;')
css = css.replace('font-family: \'Outfit\', sans-serif;', 'font-family: \'Outfit\', sans-serif;\n    letter-spacing: -0.02em;')

# 2. Glassmorphism tweaks
# In root:
css = css.replace('--glass-bg: rgba(255, 255, 255, 0.03);', '--glass-bg: rgba(20, 20, 25, 0.6);')
css = css.replace('--glass-border: rgba(255, 255, 255, 0.08);', '--glass-border: rgba(255, 255, 255, 0.05);')
# Add shadow to .glass
if 'box-shadow: 0 4px 6px' not in css:
    css = css.replace('border-radius: 16px;', 'border-radius: 16px;\n    box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1), 0 24px 48px -12px rgba(0,0,0,0.5);')

# 3. Button adjustments
css = css.replace('padding: 0.8rem 1.8rem;', 'padding: 12px 24px;')
# Make sure .btn has transform
if 'transform: translateY' not in css.split('.btn {')[1].split('}')[0]:
    pass # Wait, hover state has it

# 4. Section padding (from 100px to 120px on desktop)
css = re.sub(r'padding: 100px 0 !important;', 'padding: 120px 0;', css)
css = re.sub(r'padding: 100px 0;', 'padding: 120px 0;', css)
# Ensure mobile is 60px
css = css.replace('padding: 60px 0 !important;', 'padding: 60px 0;')

# 5. Alternating Backgrounds
# Add subtle backgrounds to specific sections to separate them
alternating_bg = """
.how-it-works, .faq {
    background: linear-gradient(180deg, var(--bg-dark) 0%, #0d0d14 50%, var(--bg-dark) 100%);
}
"""
if '.how-it-works, .faq {' not in css:
    css += '\n' + alternating_bg

with open(css_file, 'w', encoding='utf-8') as f:
    f.write(css)

print("UI Refined in style.css")
