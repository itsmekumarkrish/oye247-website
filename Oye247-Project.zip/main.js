document.addEventListener('DOMContentLoaded', () => {
    // Chatbot Elements
    const chatbotTrigger = document.getElementById('chatbot-trigger');
    const chatbotWindow = document.getElementById('chatbot-window');
    const closeChatBtn = document.getElementById('close-chat');
    const chatbotBody = document.getElementById('chatbot-body');
    const chatbotOptions = document.getElementById('chatbot-options');
    const waCtaArea = document.getElementById('wa-cta-area');

    // Toggle Chatbot
    chatbotTrigger.addEventListener('click', () => {
        chatbotWindow.classList.toggle('active');
        if(chatbotWindow.classList.contains('active')) {
            // Optional: reset chat if needed, but keeping state is fine for now
            setTimeout(() => {
                chatbotWindow.style.display = 'flex';
            }, 10);
        } else {
            setTimeout(() => {
                chatbotWindow.style.display = 'none';
            }, 300); // match transition duration
        }
    });

    closeChatBtn.addEventListener('click', () => {
        chatbotWindow.classList.remove('active');
        setTimeout(() => {
            chatbotWindow.style.display = 'none';
        }, 300);
    });

    // Setup initial state for display toggle properly
    chatbotWindow.style.display = 'none';
    
    // Add event listener to the trigger to handle the block vs none display issue with transitions
    chatbotTrigger.addEventListener('click', (e) => {
        if(chatbotWindow.style.display === 'none') {
            chatbotWindow.style.display = 'flex';
            // Trigger reflow to ensure transition happens
            void chatbotWindow.offsetWidth; 
            chatbotWindow.classList.add('active');
        } else {
            chatbotWindow.classList.remove('active');
            setTimeout(() => {
                chatbotWindow.style.display = 'none';
            }, 300);
        }
    });

    // Remove the duplicate listener above, just overriding it here to be safe
    chatbotTrigger.replaceWith(chatbotTrigger.cloneNode(true));
    const newChatbotTrigger = document.getElementById('chatbot-trigger');
    
    newChatbotTrigger.addEventListener('click', () => {
        if(chatbotWindow.classList.contains('active')) {
            chatbotWindow.classList.remove('active');
            setTimeout(() => {
                chatbotWindow.style.display = 'none';
            }, 300);
        } else {
            chatbotWindow.style.display = 'flex';
            setTimeout(() => {
                chatbotWindow.classList.add('active');
            }, 10);
        }
    });

    // Chatbot Flow Logic
    const chatFlow = {
        question1: {
            bot: "Great! What industry are you in?",
            options: ["E-commerce", "SaaS / Tech", "Service Based", "Other"]
        },
        question2: {
            bot: "Got it. How many leads do you typically get per month?",
            options: ["Under 50", "50 - 200", "200+"]
        },
        final: {
            bot: "Awesome. Our AI can definitely help you increase conversions. Let's chat on WhatsApp to see a quick demo tailored for you.",
            options: [] // no options, show WA button
        }
    };

    let currentStep = 0;

    // Handle Option Clicks
    chatbotOptions.addEventListener('click', (e) => {
        if(e.target.classList.contains('chat-option-btn')) {
            const userReply = e.target.getAttribute('data-reply');
            addUserMessage(userReply);
            
            // Disable options temporarily
            chatbotOptions.innerHTML = '';
            
            // Determine next bot message
            setTimeout(() => {
                if(currentStep === 0) {
                    addBotMessage(chatFlow.question1.bot);
                    renderOptions(chatFlow.question1.options);
                    currentStep++;
                } else if (currentStep === 1) {
                    addBotMessage(chatFlow.question2.bot);
                    renderOptions(chatFlow.question2.options);
                    currentStep++;
                } else if (currentStep === 2) {
                    addBotMessage(chatFlow.final.bot);
                    waCtaArea.style.display = 'block';
                    currentStep++;
                }
            }, 800);
        }
    });

    function addUserMessage(text) {
        const msgDiv = document.createElement('div');
        msgDiv.className = 'chat-message user-message';
        msgDiv.textContent = text;
        chatbotBody.appendChild(msgDiv);
        scrollToBottom();
    }

    function addBotMessage(text) {
        const msgDiv = document.createElement('div');
        msgDiv.className = 'chat-message bot-message';
        msgDiv.textContent = text;
        chatbotBody.appendChild(msgDiv);
        scrollToBottom();
    }

    function renderOptions(optionsArray) {
        chatbotOptions.innerHTML = '';
        optionsArray.forEach(opt => {
            const btn = document.createElement('button');
            btn.className = 'chat-option-btn';
            btn.setAttribute('data-reply', opt);
            btn.textContent = opt;
            chatbotOptions.appendChild(btn);
        });
    }

    function scrollToBottom() {
        chatbotBody.scrollTop = chatbotBody.scrollHeight;
    }

    // Smooth Scroll Offset for Navbar
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const targetId = this.getAttribute('href');
            if(targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if(targetElement) {
                e.preventDefault();
                const headerOffset = 80; // approximate navbar height
                const elementPosition = targetElement.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
  
                window.scrollTo({
                     top: offsetPosition,
                     behavior: "smooth"
                });
            }
        });
    });

    // --- Canvas Animated Background ---
    const canvas = document.getElementById('hero-canvas');
    if (canvas) {
        const ctx = canvas.getContext('2d');
        let width, height;
        let particles = [];
        let mouse = { x: null, y: null };
        let orbs = [];

        function resize() {
            width = canvas.width = canvas.parentElement.offsetWidth;
            height = canvas.height = canvas.parentElement.offsetHeight;
        }
        window.addEventListener('resize', resize);
        resize();

        // Track mouse for parallax
        const heroSection = document.querySelector('.hero');
        heroSection.addEventListener('mousemove', (e) => {
            const rect = canvas.getBoundingClientRect();
            mouse.x = e.clientX - rect.left;
            mouse.y = e.clientY - rect.top;
        });
        heroSection.addEventListener('mouseleave', () => {
            mouse.x = null;
            mouse.y = null;
        });

        // Orbs for background gradient glow
        class Orb {
            constructor(x, y, r, color, vx, vy) {
                this.x = x;
                this.y = y;
                this.r = r;
                this.color = color;
                this.vx = vx;
                this.vy = vy;
            }
            update() {
                this.x += this.vx;
                this.y += this.vy;
                if (this.x < -this.r || this.x > width + this.r) this.vx *= -1;
                if (this.y < -this.r || this.y > height + this.r) this.vy *= -1;
            }
            draw() {
                ctx.save();
                ctx.globalAlpha = 0.4; // even softer glow
                const g = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, this.r);
                g.addColorStop(0, this.color);
                g.addColorStop(1, 'rgba(10, 10, 15, 0)');
                ctx.fillStyle = g;
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
                ctx.fill();
                ctx.restore();
            }
        }

        // Initialize orbs with requested colors - larger radius, lower opacity, slower speed
        // Teal, Purple, Blue
        orbs.push(new Orb(width * 0.2, height * 0.3, 350, 'rgba(20, 241, 217, 0.06)', 0.15, 0.1)); 
        orbs.push(new Orb(width * 0.8, height * 0.6, 450, 'rgba(139, 92, 246, 0.06)', -0.1, 0.15)); 
        orbs.push(new Orb(width * 0.5, height * 0.8, 300, 'rgba(59, 130, 246, 0.06)', 0.1, -0.1)); 

        // Particles
        class Particle {
            constructor() {
                this.x = Math.random() * width;
                this.y = Math.random() * height;
                this.vx = (Math.random() - 0.5) * 0.15; // slow movement
                this.vy = (Math.random() - 0.5) * 0.15;
                this.radius = Math.random() * 1.2 + 0.5; // slightly smaller
                this.baseX = this.x;
                this.baseY = this.y;
            }
            update() {
                this.baseX += this.vx;
                this.baseY += this.vy;

                // wrap around
                if (this.baseX < 0) this.baseX = width;
                if (this.baseX > width) this.baseX = 0;
                if (this.baseY < 0) this.baseY = height;
                if (this.baseY > height) this.baseY = 0;

                // parallax
                if (mouse.x != null) {
                    let dx = mouse.x - width/2;
                    let dy = mouse.y - height/2;
                    // gentle shift opposite to mouse
                    this.x = this.baseX - dx * 0.015; // subtle parallax
                    this.y = this.baseY - dy * 0.015;
                } else {
                    this.x = this.baseX;
                    this.y = this.baseY;
                }
            }
            draw() {
                ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
                ctx.fill();
            }
        }

        // Less particles on mobile for performance and subtlety
        const numParticles = window.innerWidth < 768 ? 20 : 50;
        for (let i = 0; i < numParticles; i++) {
            particles.push(new Particle());
        }

        function animate() {
            ctx.clearRect(0, 0, width, height);
            
            // Draw Orbs
            orbs.forEach(orb => {
                orb.update();
                orb.draw();
            });

            // Draw Particles and connecting lines
            for (let i = 0; i < particles.length; i++) {
                particles[i].update();
                particles[i].draw();
                
                for (let j = i + 1; j < particles.length; j++) {
                    const dx = particles[i].x - particles[j].x;
                    const dy = particles[i].y - particles[j].y;
                    const dist = Math.sqrt(dx * dx + dy * dy);
                    
                    if (dist < 120) {
                        ctx.beginPath();
                        ctx.strokeStyle = `rgba(255, 255, 255, ${0.05 * (1 - dist/120)})`; // softer lines
                        ctx.lineWidth = 0.5;
                        ctx.moveTo(particles[i].x, particles[i].y);
                        ctx.lineTo(particles[j].x, particles[j].y);
                        ctx.stroke();
                    }
                }
            }
            requestAnimationFrame(animate);
        }
        animate();
    }


    // --- Trusted Logos Canvas ---
    const logosCanvas = document.getElementById('logos-canvas');
    if (logosCanvas) {
        const ctxL = logosCanvas.getContext('2d');
        let widthL, heightL;
        let stars = [];

        function resizeL() {
            widthL = logosCanvas.width = logosCanvas.parentElement.offsetWidth;
            heightL = logosCanvas.height = logosCanvas.parentElement.offsetHeight;
        }
        window.addEventListener('resize', resizeL);
        resizeL();

        class Star {
            constructor() {
                this.x = Math.random() * widthL;
                this.y = Math.random() * heightL;
                this.vx = (Math.random() - 0.5) * 0.1;
                this.vy = (Math.random() - 0.5) * 0.1;
                this.radius = Math.random() * 1.2;
                this.alpha = Math.random() * 0.5 + 0.1;
            }
            update() {
                this.x += this.vx;
                this.y += this.vy;
                if (this.x < 0) this.x = widthL;
                if (this.x > widthL) this.x = 0;
                if (this.y < 0) this.y = heightL;
                if (this.y > heightL) this.y = 0;
            }
            draw() {
                ctxL.fillStyle = `rgba(255, 255, 255, ${this.alpha})`;
                ctxL.beginPath();
                ctxL.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
                ctxL.fill();
            }
        }

        const numStars = window.innerWidth < 768 ? 15 : 30;
        for (let i = 0; i < numStars; i++) {
            stars.push(new Star());
        }

        function animateL() {
            ctxL.clearRect(0, 0, widthL, heightL);
            stars.forEach(s => {
                s.update();
                s.draw();
            });
            requestAnimationFrame(animateL);
        }
        animateL();
    }

    // --- Intersection Observer for Scroll Animations ---
    const fadeUpElements = document.querySelectorAll('.fade-up');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, {
        root: null,
        rootMargin: '0px',
        threshold: 0.15
    });

    fadeUpElements.forEach(el => observer.observe(el));

    // --- FAQ Accordion Logic ---
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const questionBtn = item.querySelector('.faq-question');
        const answer = item.querySelector('.faq-answer');
        
        questionBtn.addEventListener('click', () => {
            const isActive = item.classList.contains('active');
            
            // Close all other FAQs
            faqItems.forEach(otherItem => {
                otherItem.classList.remove('active');
                const otherAnswer = otherItem.querySelector('.faq-answer');
                otherAnswer.style.maxHeight = '0';
            });
            
            // Toggle clicked FAQ
            if (!isActive) {
                item.classList.add('active');
                answer.style.maxHeight = answer.scrollHeight + 'px';
            }
        });
    });

    // --- Contact Form Logic ---
    const contactForm = document.getElementById('contact-form');
    const submitBtn = document.getElementById('form-submit-btn');
    const btnText = document.getElementById('btn-text');
    const btnLoading = document.getElementById('btn-loading');
    const formWrap = document.getElementById('contact-form-wrap');
    const successWrap = document.getElementById('contact-success');
    const nameInput = document.getElementById('contact-name');
    const phoneInput = document.getElementById('contact-phone');
    const emailInput = document.getElementById('contact-email');

    // Validation helpers
    function isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    function updateFieldValidation(input, isValid) {
        const group = input.closest('.floating-group');
        if (!group) return;
        if (isValid && input.value.trim().length > 0) {
            group.classList.add('valid');
            input.classList.remove('error');
        } else {
            group.classList.remove('valid');
        }
    }

    // Enable/disable submit button + update checkmarks
    function checkFormValidity() {
        const nameValid = nameInput && nameInput.value.trim().length >= 2;
        const phoneValid = phoneInput && phoneInput.value.trim().length >= 6;
        
        if (nameInput) updateFieldValidation(nameInput, nameValid);
        if (phoneInput) updateFieldValidation(phoneInput, phoneValid);
        if (emailInput) updateFieldValidation(emailInput, emailInput.value.trim() === '' || isValidEmail(emailInput.value.trim()));

        if (submitBtn) {
            submitBtn.disabled = !(nameValid && phoneValid);
        }
    }

    // Listen for input on all fields
    if (nameInput) {
        nameInput.addEventListener('input', () => {
            nameInput.classList.remove('error');
            checkFormValidity();
        });
    }
    if (phoneInput) {
        phoneInput.addEventListener('input', () => {
            phoneInput.classList.remove('error');
            checkFormValidity();
        });
    }
    if (emailInput) {
        emailInput.addEventListener('input', checkFormValidity);
    }

    // Form submission
    if (contactForm) {
        contactForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            // Collect form data
            const formData = {
                name: nameInput.value.trim(),
                phone: phoneInput.value.trim(),
                email: emailInput?.value.trim() || '',
                business: document.getElementById('contact-business')?.value || '',
                leads: document.getElementById('contact-leads')?.value || '',
                message: document.getElementById('contact-message')?.value.trim() || ''
            };

            // Validate required
            let hasError = false;
            if (!formData.name) {
                nameInput.classList.add('error');
                nameInput.closest('.floating-group')?.classList.remove('valid');
                hasError = true;
            }
            if (!formData.phone) {
                phoneInput.classList.add('error');
                phoneInput.closest('.floating-group')?.classList.remove('valid');
                hasError = true;
            }
            if (hasError) return;

            // Show loading state
            btnText.style.display = 'none';
            btnLoading.style.display = 'inline-flex';
            submitBtn.disabled = true;

            try {
                const response = await fetch('http://localhost:3000/api/contact', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(formData)
                });

                if (response.ok) {
                    formWrap.style.display = 'none';
                    successWrap.style.display = 'block';
                } else {
                    throw new Error('Server error');
                }
            } catch (err) {
                // Frontend-only fallback: show success even if backend is offline
                formWrap.style.display = 'none';
                successWrap.style.display = 'block';
                console.log('Form submitted (backend offline, data logged):', formData);
            }
        });
    }
});


// Mobile Navigation Toggle
const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
const mobileMenuClose = document.querySelector('.mobile-menu-close');
const mobileNav = document.querySelector('.mobile-nav');
const mobileLinks = document.querySelectorAll('.mobile-links a');

if (mobileMenuBtn && mobileNav && mobileMenuClose) {
    mobileMenuBtn.addEventListener('click', () => {
        mobileNav.classList.add('active');
        document.body.style.overflow = 'hidden'; // Prevent background scrolling
    });

    mobileMenuClose.addEventListener('click', () => {
        mobileNav.classList.remove('active');
        document.body.style.overflow = '';
    });

    // Close menu when a link is clicked
    mobileLinks.forEach(link => {
        link.addEventListener('click', () => {
            mobileNav.classList.remove('active');
            document.body.style.overflow = '';
        });
    });
}
