import re

css_file = 'style.css'
with open(css_file, 'r', encoding='utf-8') as f:
    css_content = f.read()

# Standardize section paddings to 100px 0
replacements = [
    (r'\.use-cases \{\n    padding: 6rem 0;', '.use-cases {\n    padding: 100px 0;'),
    (r'\.solution \{\n    padding: 8rem 0;', '.solution {\n    padding: 100px 0;'),
    (r'\.how-it-works \{\n    padding: 8rem 0;', '.how-it-works {\n    padding: 100px 0;'),
    (r'\.testimonials \{\n    padding: 8rem 0;', '.testimonials {\n    padding: 100px 0;'),
    (r'\.faq \{\n    padding: 80px 0;', '.faq {\n    padding: 100px 0;'),
    (r'\.contact \{\n    padding: 10rem 0;', '.contact {\n    padding: 100px 0;')
]

for old, new in replacements:
    css_content = re.sub(old, new, css_content)

# Add CTA section CSS
cta_css = """
/* CTA Section */
.cta-section {
    padding: 100px 0;
    border-top: 1px solid rgba(255, 255, 255, 0.05);
    background: linear-gradient(180deg, transparent, rgba(20, 241, 217, 0.02));
}

.cta-section h2 {
    font-size: 3rem;
    margin-bottom: 1rem;
    font-family: 'Outfit', sans-serif;
}

.cta-section p {
    color: var(--text-muted);
    font-size: 1.1rem;
    margin-bottom: 2.5rem;
}

/* Premium Footer */"""

css_content = css_content.replace('/* Premium Footer */', cta_css)

with open(css_file, 'w', encoding='utf-8') as f:
    f.write(css_content)

print("style.css updated")

# Add CTA section HTML to index.html
html_file = 'index.html'
with open(html_file, 'r', encoding='utf-8') as f:
    html_content = f.read()

cta_html = """    <!-- CTA Section -->
    <section class="cta-section fade-up" id="cta">
        <div class="container text-center">
            <h2>Ready to <span class="text-gradient">Scale?</span></h2>
            <p>Join futuristic businesses automating their growth today.</p>
            <a href="#contact" class="btn btn-primary mt-4">Get Your Automation Plan</a>
        </div>
    </section>

    <!-- Premium Footer -->"""

if '<!-- CTA Section -->' not in html_content:
    html_content = html_content.replace('<!-- Premium Footer -->', cta_html)
    with open(html_file, 'w', encoding='utf-8') as f:
        f.write(html_content)
    print("index.html updated")

