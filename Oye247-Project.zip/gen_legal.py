import os

footer_html = """    <!-- Premium Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <div class="logo">
                        <i class="ph ph-robot"></i> Oye247
                    </div>
                    <p class="footer-desc">Automating the future of business. Capture leads, book meetings, and scale effortlessly with intelligent AI agents.</p>
                    <div class="footer-socials">
                        <a href="#"><i class="ph ph-twitter-logo"></i></a>
                        <a href="#"><i class="ph ph-linkedin-logo"></i></a>
                        <a href="#"><i class="ph ph-instagram-logo"></i></a>
                    </div>
                </div>
                
                <div class="footer-links">
                    <h4>Product</h4>
                    <ul>
                        <li><a href="/#features">Features</a></li>
                        <li><a href="/#use-cases">Use Cases</a></li>
                        <li><a href="/#testimonials">Testimonials</a></li>
                        <li><a href="/#pricing">Pricing</a></li>
                    </ul>
                </div>

                <div class="footer-links">
                    <h4>Support & Legal</h4>
                    <ul>
                        <li><a href="/contact">Contact Us</a></li>
                        <li><a href="/privacy-policy">Privacy Policy</a></li>
                        <li><a href="/terms-of-service">Terms of Service</a></li>
                        <li><a href="/refund-policy">Refund Policy</a></li>
                        <li><a href="/disclaimer">Disclaimer</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2026 Oye247. All rights reserved.</p>
                <div class="footer-bottom-links">
                    <a href="/privacy-policy">Privacy</a>
                    <span class="dot">•</span>
                    <a href="/terms-of-service">Terms</a>
                </div>
            </div>
        </div>
    </footer>
"""

def make_html(title, content):
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} | Oye247</title>
    <!-- Phosphor Icons -->
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body class="dark-theme">
    <nav class="minimal-nav">
        <a href="/" class="logo">
            <i class="ph ph-robot"></i> Oye247
        </a>
        <a href="/" class="back-link">
            <i class="ph ph-arrow-left"></i> Back to Home
        </a>
    </nav>

    <main class="legal-page">
        <div class="container fade-up">
            <div class="legal-header">
                <h1>{title}</h1>
                <p>Last updated: 2026</p>
            </div>
            <div class="legal-content">
{content}
            </div>
        </div>
    </main>

{footer_html}

    <script src="main.js"></script>
</body>
</html>"""

privacy_content = """                <p>Oye247 ("we", "our", "us") respects your privacy and is committed to protecting your personal data.</p>
                <hr>
                <h3>1. Information We Collect</h3>
                <ul>
                    <li>Name</li>
                    <li>Email address</li>
                    <li>Phone number</li>
                    <li>Business details</li>
                    <li>Usage data (IP, browser, pages visited)</li>
                </ul>
                <hr>
                <h3>2. How We Use Your Data</h3>
                <ul>
                    <li>Provide AI automation services</li>
                    <li>Respond to inquiries</li>
                    <li>Improve platform performance</li>
                    <li>Send relevant communication</li>
                </ul>
                <hr>
                <h3>3. Data Sharing</h3>
                <p>We do not sell your data.<br>We may share data only with trusted providers (hosting, analytics, communication tools).</p>
                <hr>
                <h3>4. Data Security</h3>
                <p>We use industry-standard security practices to protect your information.</p>
                <hr>
                <h3>5. Cookies</h3>
                <p>We use cookies to enhance user experience and performance tracking.</p>
                <hr>
                <h3>6. Data Retention</h3>
                <p>We retain data only as long as necessary for service or legal compliance.</p>
                <hr>
                <h3>7. Your Rights</h3>
                <p>You can request access, correction, or deletion of your data.<br>Contact: support@oye247.com</p>
                <hr>
                <h3>8. Third-Party Services</h3>
                <p>We may integrate with external platforms (WhatsApp, CRM tools). Their policies apply separately.</p>
                <hr>
                <h3>9. Updates</h3>
                <p>We may update this policy at any time.</p>
                <hr>
                <h3>10. Contact</h3>
                <p>support@oye247.com</p>"""

refund_content = """                <hr>
                <h3>1. General Policy</h3>
                <p>All payments made to Oye247 are non-refundable, unless explicitly stated otherwise.</p>
                <hr>
                <h3>2. Exceptions</h3>
                <p>Refunds may be considered only if:</p>
                <ul>
                    <li>Service was not delivered</li>
                    <li>Technical failure on our side</li>
                </ul>
                <hr>
                <h3>3. No Refund Cases</h3>
                <p>No refunds will be issued for:</p>
                <ul>
                    <li>Change of mind</li>
                    <li>Misunderstanding of service</li>
                    <li>Partial usage</li>
                </ul>
                <hr>
                <h3>4. Processing Time</h3>
                <p>Approved refunds (if any) will be processed within 7–10 business days.</p>
                <hr>
                <h3>5. Contact</h3>
                <p>support@oye247.com</p>"""

disclaimer_content = """                <p>Oye247 provides AI automation tools intended to assist business operations.</p>
                <hr>
                <h3>1. No Guarantees</h3>
                <p>We do not guarantee:</p>
                <ul>
                    <li>Specific revenue</li>
                    <li>Lead conversion rates</li>
                    <li>Business outcomes</li>
                </ul>
                <hr>
                <h3>2. Use at Your Own Risk</h3>
                <p>All decisions made using our system are the user’s responsibility.</p>
                <hr>
                <h3>3. Third-Party Tools</h3>
                <p>We are not responsible for issues caused by third-party platforms.</p>
                <hr>
                <h3>4. Accuracy</h3>
                <p>While we aim for accuracy, AI-generated outputs may not always be perfect.</p>
                <hr>
                <h3>5. Contact</h3>
                <p>support@oye247.com</p>"""

terms_content = """                <p>Welcome to Oye247. By accessing or using our platform, you agree to comply with and be bound by these Terms of Service.</p>
                <hr>
                <h3>1. Acceptance of Terms</h3>
                <p>By using Oye247, you agree to these Terms. If you do not agree to these terms, please do not use our services.</p>
                <hr>
                <h3>2. Service Description</h3>
                <p>Oye247 provides artificial intelligence automation tools designed to assist with lead generation, customer support, and operational workflows.</p>
                <hr>
                <h3>3. User Responsibilities</h3>
                <ul>
                    <li>You must provide accurate account information.</li>
                    <li>You are responsible for maintaining the security of your account credentials.</li>
                    <li>You agree not to use the service for any illegal or unauthorized purpose.</li>
                </ul>
                <hr>
                <h3>4. Payment and Subscriptions</h3>
                <p>Services are billed on a subscription basis. You will be billed in advance on a recurring schedule. Failure to pay may result in suspension of services.</p>
                <hr>
                <h3>5. Intellectual Property</h3>
                <p>All content, features, and functionality of the Oye247 platform are owned by Oye247 and are protected by international copyright and trademark laws.</p>
                <hr>
                <h3>6. Limitation of Liability</h3>
                <p>In no event shall Oye247 be liable for any indirect, incidental, special, consequential or punitive damages resulting from your use of the service.</p>
                <hr>
                <h3>7. Termination</h3>
                <p>We may terminate or suspend your access immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.</p>
                <hr>
                <h3>8. Contact Us</h3>
                <p>If you have any questions about these Terms, please contact us at support@oye247.com.</p>"""

contact_content = """                <p>If you have any legal inquiries, data requests, or require administrative support, please use the contact information provided below.</p>
                <hr>
                <h3>General Support & Legal Inquiries</h3>
                <p><strong>Email:</strong> support@oye247.com</p>
                <p>We aim to respond to all legal and data privacy inquiries within 48 business hours.</p>
                <hr>
                <h3>Data Protection Officer (DPO)</h3>
                <p>For requests related to your data rights under GDPR or CCPA (access, deletion, modification), please email us with the subject line <strong>"Data Subject Request"</strong>.</p>
                <hr>
                <h3>Business Address</h3>
                <p>
                    Oye247 Inc.<br>
                    123 Innovation Drive, Suite 400<br>
                    San Francisco, CA 94105<br>
                    United States
                </p>"""

files = {
    'privacy-policy.html': ('Privacy Policy', privacy_content),
    'refund-policy.html': ('Refund Policy', refund_content),
    'disclaimer.html': ('Disclaimer', disclaimer_content),
    'terms-of-service.html': ('Terms of Service', terms_content),
    'contact.html': ('Legal Contact', contact_content)
}

for filename, (title, content) in files.items():
    with open(filename, 'w') as f:
        f.write(make_html(title, content))

print("Created 5 HTML files.")
