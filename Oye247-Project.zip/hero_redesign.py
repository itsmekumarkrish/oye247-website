import re

html_file = 'index.html'
with open(html_file, 'r', encoding='utf-8') as f:
    html = f.read()

# 1. Update Fonts
old_fonts = 'family=Inter:wght@300;400;500;600&family=Outfit:wght@400;600;700;800&display=swap'
new_fonts = 'family=Inter:wght@300;400;500;600&family=Outfit:wght@400;600;700;800&family=Playfair+Display:ital,wght@0,400;0,500;0,600;1,400;1,500;1,600&display=swap'
html = html.replace(old_fonts, new_fonts)

# 2. Replace Hero Section
old_hero_regex = r'<section class="hero">.*?</section>'
new_hero_html = """<section class="hero redesigned-hero">
        <div class="container hero-container">
            <div class="hero-top-label fade-up">#1 AI VOICE AGENT PLATFORM FOR AUTOMATING CALLS</div>
            
            <h1 class="hero-serif-headline fade-up" style="animation-delay: 0.1s;">
                Meet your AI call center<br>from the future.
            </h1>
            
            <div class="hero-bottom-bar fade-up" style="animation-delay: 0.2s;">
                <div class="hero-bottom-left">
                    <div class="g2-badge">
                        <span class="g-logo">G</span>
                        <div class="stars">
                            <i class="ph-fill ph-star"></i>
                            <i class="ph-fill ph-star"></i>
                            <i class="ph-fill ph-star"></i>
                            <i class="ph-fill ph-star"></i>
                            <i class="ph-fill ph-star-half"></i>
                        </div>
                        <span class="rating">4.8</span>
                    </div>
                    <p>Build, deploy, and manage next-generation AI voice<br>agents that sound human, execute tasks, and scale<br>effortlessly.</p>
                </div>
                
                <div class="hero-bottom-right">
                    <a href="#demo" class="live-demo-btn">
                        <span class="demo-text">Try Our Live<br>Demo</span>
                        <div class="demo-orb-wrapper">
                            <div class="demo-orb"></div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>"""
html = re.sub(old_hero_regex, new_hero_html, html, flags=re.DOTALL)

with open(html_file, 'w', encoding='utf-8') as f:
    f.write(html)
print("Updated index.html")

# 3. Update style.css
css_file = 'style.css'
with open(css_file, 'r', encoding='utf-8') as f:
    css = f.read()

new_hero_css = """
/* --- Redesigned Hero Section --- */
.redesigned-hero {
    position: relative;
    padding-top: 180px;
    padding-bottom: 80px;
    min-height: 90vh;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    background: radial-gradient(circle at 50% 40%, #002d6b 0%, #001233 60%, #050508 100%);
    overflow: hidden;
}

/* Subtle glow overlays to match screenshot */
.redesigned-hero::before {
    content: '';
    position: absolute;
    top: 20%;
    left: -10%;
    width: 600px;
    height: 600px;
    background: radial-gradient(circle, rgba(56, 189, 248, 0.15) 0%, transparent 70%);
    border-radius: 50%;
    z-index: 0;
}

.redesigned-hero::after {
    content: '';
    position: absolute;
    bottom: -10%;
    right: 10%;
    width: 700px;
    height: 700px;
    background: radial-gradient(circle, rgba(14, 165, 233, 0.1) 0%, transparent 70%);
    border-radius: 50%;
    z-index: 0;
}

.hero-container {
    position: relative;
    z-index: 2;
    display: flex;
    flex-direction: column;
    height: 100%;
    flex: 1;
}

.hero-top-label {
    text-align: center;
    font-size: 0.75rem;
    letter-spacing: 1px;
    color: rgba(255, 255, 255, 0.7);
    text-transform: uppercase;
    margin-bottom: 2.5rem;
    font-weight: 500;
}

.hero-serif-headline {
    text-align: center;
    font-family: 'Playfair Display', serif;
    font-size: 5.5rem;
    line-height: 1.05;
    font-weight: 400;
    color: #ffffff;
    letter-spacing: -1px;
    margin-bottom: auto; /* Pushes bottom bar down */
}

/* Bottom Bar Flex Layout */
.hero-bottom-bar {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    margin-top: 8rem;
    width: 100%;
}

.hero-bottom-left {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.g2-badge {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    background: rgba(255, 255, 255, 0.1);
    padding: 0.3rem 0.6rem;
    border-radius: 4px;
    width: fit-content;
    font-size: 0.8rem;
    color: #ffffff;
    border: 1px solid rgba(255, 255, 255, 0.2);
}

.g-logo {
    font-weight: bold;
    font-size: 0.9rem;
}

.stars {
    color: #ffffff;
    display: flex;
    gap: 2px;
}

.hero-bottom-left p {
    font-size: 0.9rem;
    line-height: 1.5;
    color: rgba(255, 255, 255, 0.7);
    margin: 0;
}

/* Custom Live Demo Button */
.live-demo-btn {
    display: flex;
    align-items: center;
    gap: 1.5rem;
    background: rgba(255, 255, 255, 0.15);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    padding: 0.5rem 0.5rem 0.5rem 1.5rem;
    border-radius: 12px;
    text-decoration: none;
    color: #ffffff;
    transition: transform 0.3s ease, background 0.3s ease;
}

.live-demo-btn:hover {
    transform: translateY(-2px);
    background: rgba(255, 255, 255, 0.2);
}

.demo-text {
    font-size: 0.95rem;
    line-height: 1.3;
    font-weight: 500;
}

.demo-orb-wrapper {
    width: 48px;
    height: 48px;
    background: #ffffff;
    border-radius: 8px;
    display: flex;
    justify-content: center;
    align-items: center;
}

.demo-orb {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    /* Multi-colored glowing orb gradient matching the screenshot */
    background: radial-gradient(circle at 30% 30%, #fff, #fca5a5 20%, #c4b5fd 50%, #7dd3fc 80%, #38bdf8 100%);
    box-shadow: 0 0 10px rgba(125, 211, 252, 0.5);
    animation: orbPulse 3s infinite alternate;
}

@keyframes orbPulse {
    0% { transform: scale(0.95); filter: hue-rotate(0deg); }
    100% { transform: scale(1.05); filter: hue-rotate(15deg); }
}

@media (max-width: 992px) {
    .hero-serif-headline {
        font-size: 4rem;
    }
}

@media (max-width: 768px) {
    .hero-serif-headline {
        font-size: 2.8rem !important;
        line-height: 1.1;
    }
    .hero-bottom-bar {
        flex-direction: column;
        align-items: flex-start;
        gap: 2.5rem;
        margin-top: 4rem;
    }
    .live-demo-btn {
        width: 100%;
        justify-content: space-between;
    }
}
"""
css = css + '\n' + new_hero_css
with open(css_file, 'w', encoding='utf-8') as f:
    f.write(css)
print("Updated style.css")
