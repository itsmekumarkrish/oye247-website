import re

# --- Update index.html ---
html_file = 'index.html'
with open(html_file, 'r', encoding='utf-8') as f:
    html = f.read()

# Add mobile menu button
if 'class="mobile-menu-btn"' not in html:
    html = html.replace('<div class="nav-links">', '<button class="mobile-menu-btn" aria-label="Toggle menu"><i class="ph ph-list"></i></button>\n            <div class="nav-links">')

# Add mobile nav container
mobile_nav_html = """    <!-- Mobile Navigation Overlay -->
    <div class="mobile-nav">
        <div class="mobile-nav-content">
            <button class="mobile-menu-close" aria-label="Close menu"><i class="ph ph-x"></i></button>
            <div class="mobile-links">
                <a href="#how-it-works">How It Works</a>
                <a href="#benefits">Benefits</a>
                <a href="#contact" class="btn btn-primary">Get Demo</a>
            </div>
        </div>
    </div>
"""
if '<div class="mobile-nav">' not in html:
    html = html.replace('</nav>\n', f'</nav>\n\n{mobile_nav_html}')

with open(html_file, 'w', encoding='utf-8') as f:
    f.write(html)
print("Updated index.html")

# --- Update style.css ---
css_file = 'style.css'
with open(css_file, 'r', encoding='utf-8') as f:
    css = f.read()

responsive_css = """
/* --- Mobile Menu Styles --- */
.mobile-menu-btn {
    display: none;
    background: none;
    border: none;
    color: var(--text-main);
    font-size: 1.8rem;
    cursor: pointer;
    z-index: 1000;
}

.mobile-nav {
    position: fixed;
    top: 0;
    right: -100%;
    width: 100%;
    height: 100vh;
    background: rgba(10, 10, 15, 0.95);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    z-index: 9999;
    transition: right 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    display: flex;
    justify-content: center;
    align-items: center;
}

.mobile-nav.active {
    right: 0;
}

.mobile-nav-content {
    text-align: center;
    width: 100%;
    padding: 2rem;
}

.mobile-menu-close {
    position: absolute;
    top: 1.5rem;
    right: 1.5rem;
    background: none;
    border: none;
    color: var(--text-main);
    font-size: 2rem;
    cursor: pointer;
}

.mobile-links {
    display: flex;
    flex-direction: column;
    gap: 2rem;
    align-items: center;
}

.mobile-links a {
    color: var(--text-main);
    text-decoration: none;
    font-size: 1.5rem;
    font-family: 'Outfit', sans-serif;
    font-weight: 500;
    transition: color 0.3s ease;
}

.mobile-links a:hover {
    color: var(--accent-teal);
}

.mobile-links .btn {
    width: 100%;
    max-width: 300px;
    margin-top: 1rem;
    font-size: 1.2rem;
}

/* --- Global Responsive Fixes --- */
@media (max-width: 992px) {
    .mobile-menu-btn {
        display: block;
    }
}

@media (max-width: 768px) {
    /* Base text scaling */
    html {
        font-size: 14px;
    }
    
    h1, h2, h3, p {
        word-wrap: break-word;
        overflow-wrap: break-word;
    }

    .hero h1 {
        font-size: 2.5rem !important;
        line-height: 1.2;
    }

    .hero p {
        font-size: 1.1rem;
    }

    /* Section padding normalization for mobile */
    .hero { padding-top: 120px; padding-bottom: 60px; }
    .problem, .use-cases, .solution, .how-it-works, .testimonials, .faq, .contact, .cta-section {
        padding: 60px 0 !important;
    }

    /* Button full width */
    .btn {
        width: 100%;
        text-align: center;
        justify-content: center;
    }
    
    /* Hero button grouping */
    .hero-cta {
        flex-direction: column;
        width: 100%;
        gap: 1rem;
    }
    
    .hero-cta .btn {
        width: 100%;
    }

    /* Footer adjustments */
    .footer-grid {
        grid-template-columns: 1fr;
        text-align: center;
        gap: 2rem;
    }
    .footer-links {
        align-items: center;
    }
    .footer-socials {
        justify-content: center;
    }
    .footer-bottom {
        flex-direction: column;
        gap: 1rem;
        text-align: center;
    }
    
    /* Layouts to 1 column */
    .grid-3, .grid-2x2, .solution-grid, .steps-grid, .contact-grid {
        grid-template-columns: 1fr !important;
        gap: 2rem;
    }
    
    /* Form */
    .form-row {
        grid-template-columns: 1fr !important;
        gap: 1rem;
    }
    
    /* Hide desktop nav inside existing max-width: 768px if not already handled */
}

@media (max-width: 480px) {
    /* Very small devices */
    .hero h1 {
        font-size: 2.2rem !important;
    }
    .section-header h2 {
        font-size: 2rem !important;
    }
    .contact-form-card {
        padding: 1.5rem !important;
    }
}
"""

if '/* --- Mobile Menu Styles --- */' not in css:
    css = css + '\n' + responsive_css
    with open(css_file, 'w', encoding='utf-8') as f:
        f.write(css)
    print("Updated style.css")

# --- Update main.js ---
js_file = 'main.js'
with open(js_file, 'r', encoding='utf-8') as f:
    js = f.read()

js_code = """
// Mobile Navigation Toggle
const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
const mobileMenuClose = document.querySelector('.mobile-menu-close');
const mobileNav = document.querySelector('.mobile-nav');
const mobileLinks = document.querySelectorAll('.mobile-links a');

if (mobileMenuBtn && mobileNav && mobileMenuClose) {
    mobileMenuBtn.addEventListener('click', () => {
        mobileNav.classList.add('active');
        document.body.style.overflow = 'hidden'; // Prevent background scrolling
    });

    mobileMenuClose.addEventListener('click', () => {
        mobileNav.classList.remove('active');
        document.body.style.overflow = '';
    });

    // Close menu when a link is clicked
    mobileLinks.forEach(link => {
        link.addEventListener('click', () => {
            mobileNav.classList.remove('active');
            document.body.style.overflow = '';
        });
    });
}
"""

if 'Mobile Navigation Toggle' not in js:
    js = js + '\n' + js_code
    with open(js_file, 'w', encoding='utf-8') as f:
        f.write(js)
    print("Updated main.js")
