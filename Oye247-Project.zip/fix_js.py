js_file = 'main.js'
with open(js_file, 'r', encoding='utf-8') as f:
    js = f.read()

# Add a check for hero-canvas to prevent errors if it's missing
if 'const heroCanvas = document.getElementById(\'hero-canvas\');' in js:
    # Just wrap the initialization in a check or remove it
    # Easiest way: If heroCanvas doesn't exist, don't run the animation
    js = js.replace('const heroCtx = heroCanvas.getContext(\'2d\');', 'if (!heroCanvas) { /* skipped */ } else { const heroCtx = heroCanvas.getContext(\'2d\');')
    js = js.replace('heroCanvas.width = window.innerWidth;', 'if (heroCanvas) { heroCanvas.width = window.innerWidth; }')
    js = js.replace('heroCanvas.height = window.innerHeight;', 'if (heroCanvas) { heroCanvas.height = window.innerHeight; }')
    
    with open(js_file, 'w', encoding='utf-8') as f:
        f.write(js)
    print("Fixed main.js canvas errors")
